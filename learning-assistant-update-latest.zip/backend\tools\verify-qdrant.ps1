param(
    [string]$BaseUrl = $env:VECTOR_STORE_BASE_URL,
    [string]$Collection = $env:VECTOR_STORE_COLLECTION,
    [string]$ApiKey = $env:VECTOR_STORE_API_KEY,
    [switch]$Probe
)

if ([string]::IsNullOrWhiteSpace($BaseUrl)) {
    $BaseUrl = "http://127.0.0.1:6333"
}
if ([string]::IsNullOrWhiteSpace($Collection)) {
    $Collection = "learning_assistant_chunks"
}

$headers = @{}
if (-not [string]::IsNullOrWhiteSpace($ApiKey)) {
    $headers["api-key"] = $ApiKey
}

$ErrorActionPreference = "Stop"
$base = $BaseUrl.TrimEnd("/")

Write-Host "Checking Qdrant at $base ..."
$collections = Invoke-RestMethod -Method Get -Uri "$base/collections" -Headers $headers
if ($null -eq $collections.result) {
    throw "Qdrant responded, but the collections response was not recognized."
}

Write-Host "Checking collection '$Collection' ..."
try {
    $collectionInfo = Invoke-RestMethod -Method Get -Uri "$base/collections/$Collection" -Headers $headers
    Write-Host "Collection exists. Status: $($collectionInfo.result.status)"
} catch {
    Write-Host "Collection does not exist yet. The application creates it on first vector upsert."
}

if ($Probe) {
    $probeCollection = "$Collection`_probe_$(Get-Date -Format 'yyyyMMddHHmmss')"
    Write-Host "Running vector CRUD probe with temporary collection '$probeCollection' ..."

    try {
        $createBody = @{
            vectors = @{
                size = 3
                distance = "Cosine"
            }
        } | ConvertTo-Json -Depth 10
        Invoke-RestMethod -Method Put -Uri "$base/collections/$probeCollection" -Headers $headers -ContentType "application/json" -Body $createBody | Out-Null

        $upsertBody = @{
            points = @(
                @{
                    id = "11111111-1111-1111-1111-111111111111"
                    vector = @(0.1, 0.2, 0.3)
                    payload = @{
                        userId = 1
                        materialId = 1
                        chunkId = 1
                        probe = $true
                    }
                }
            )
        } | ConvertTo-Json -Depth 10
        Invoke-RestMethod -Method Put -Uri "$base/collections/$probeCollection/points?wait=true" -Headers $headers -ContentType "application/json" -Body $upsertBody | Out-Null

        $searchBody = @{
            vector = @(0.1, 0.2, 0.3)
            limit = 1
            with_payload = $true
            filter = @{
                must = @(
                    @{
                        key = "userId"
                        match = @{ value = 1 }
                    }
                )
            }
        } | ConvertTo-Json -Depth 10
        $search = Invoke-RestMethod -Method Post -Uri "$base/collections/$probeCollection/points/search" -Headers $headers -ContentType "application/json" -Body $searchBody
        if ($null -eq $search.result -or $search.result.Count -lt 1 -or $search.result[0].payload.chunkId -ne 1) {
            throw "Qdrant vector search probe did not return the expected payload."
        }

        Write-Host "Vector CRUD probe passed. Score: $($search.result[0].score)"
    } finally {
        try {
            Invoke-RestMethod -Method Delete -Uri "$base/collections/$probeCollection" -Headers $headers | Out-Null
            Write-Host "Temporary probe collection removed."
        } catch {
            Write-Warning "Failed to remove temporary probe collection '$probeCollection': $($_.Exception.Message)"
        }
    }
}

Write-Host "Qdrant verification completed."
