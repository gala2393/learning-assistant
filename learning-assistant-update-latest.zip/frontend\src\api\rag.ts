import api from '@/lib/axios'
import { useMutation, useQuery } from '@tanstack/react-query'
import { queryClient } from '@/lib/query-client'
import type {
  ChatPayload, HistoryItem, RagEvaluationSuiteDetail, RagEvaluationSuitePayload,
  RagEvaluationSuiteResult, RagEvaluationSuiteRun, RagEvaluationSuiteSavePayload,
  RagEvaluationSuiteSummary, StreamChatPayload, SummaryResult, RagSource, RagUsage,
} from '@/types'

/**
 * RAG 问答 API 模块 — 封装所有与智能问答相关的接口。
 *
 * 包含：
 * - 普通聊天（POST /rag/chat）
 * - 流式聊天 SSE（POST /rag/chat/stream）— 逐字输出 AI 回答
 * - 问答历史管理（列表、详情、删除、重命名、置顶）
 * - 资料摘要生成和历史
 * - RAG 评估套件管理（CRUD、运行、定时调度）
 * - 推荐问题生成
 * - 使用量查询
 */

const CHAT_HISTORY_CONVERSATION_KEY = 'learning-assistant.chat.history-conversations'

// ===== 普通聊天 =====

/** 普通聊天（非流式） — 一次性返回完整回答 */
export async function chat(payload: ChatPayload): Promise<HistoryItem> {
  const { data } = await api.post('/rag/chat', payload)
  return data
}

/** 获取用户的 RAG 使用量统计（剩余问答次数等） */
export async function getRagUsage(): Promise<RagUsage> {
  const { data } = await api.get('/rag/usage')
  return data
}

/**
 * SSE 流式聊天回调接口 — 定义了流式输出过程中各个阶段的回调函数。
 */
export interface StreamCallbacks {
  onSources?: (sources: RagSource[]) => void    // 收到检索到的资料来源
  onChunk?: (delta: string) => void              // 收到 AI 回答的文本增量
  onStatus?: (status: { stage?: string; message?: string }) => void  // 状态变化（检索中/思考中）
  onDone?: (result: { questionId: number | string; conversationId?: number | string; answer: string }) => void  // 流结束
  onError?: (message: string) => void            // 发生错误
}

/**
 * 流式聊天 — 通过 SSE (Server-Sent Events) 实现逐字输出。
 *
 * 为什么不直接用 Axios？因为 SSE 需要读取 response body 的 ReadableStream，
 * Axios 不支持流式读取，所以用原生 fetch API。
 *
 * SSE 协议格式（每帧由 event + data 组成，帧间用 \n\n 分隔）：
 * ```
 * event: status
 * data: {"stage":"searching"}
 *
 * event: chunk
 * data: {"delta":"TCP"}
 *
 * event: chunk
 * data: {"delta":"是"}
 *
 * event: sources
 * data: {"sources":[...]}
 *
 * event: done
 * data: {"questionId":123,"answer":"完整回答..."}
 * ```
 *
 * @param payload   聊天请求参数（问题、模式、资料ID、历史等）
 * @param callbacks 各阶段的回调函数
 * @returns AbortController，可调用 controller.abort() 取消流
 */
export function chatStream(payload: StreamChatPayload, callbacks: StreamCallbacks): AbortController {
  const controller = new AbortController()
  const base = (import.meta.env.VITE_API_BASE as string) || '/api'
  const session = localStorage.getItem('learning-assistant.frontend.session')
  const token = session ? JSON.parse(session).token : ''

  fetch(`${base}/rag/chat/stream`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify(payload),
    signal: controller.signal,
  })
    .then(async (response) => {
      if (!response.ok) { callbacks.onError?.(`请求失败 (${response.status})`); return }
      const reader = response.body?.getReader()
      if (!reader) { callbacks.onError?.('无法读取响应流'); return }

      const decoder = new TextDecoder()
      let buffer = ''           // 缓冲区（处理跨 chunk 的不完整帧）
      let receivedTerminalEvent = false

      // 解析单个 SSE 帧（event + data 组合）
      const processFrame = (frame: string) => {
        let currentEvent = ''
        const dataLines: string[] = []
        for (const rawLine of frame.split('\n')) {
          const line = rawLine.trimEnd()
          if (line.startsWith('event:')) currentEvent = line.slice(6).trim()
          else if (line.startsWith('data:')) dataLines.push(line.slice(5).trimStart())
        }
        if (!currentEvent || dataLines.length === 0) return
        try {
          const data = JSON.parse(dataLines.join('\n'))
          if (currentEvent === 'sources') callbacks.onSources?.(data.sources || [])
          else if (currentEvent === 'chunk') callbacks.onChunk?.(data.delta || '')
          else if (currentEvent === 'status') callbacks.onStatus?.(data)
          else if (currentEvent === 'done') { receivedTerminalEvent = true; callbacks.onDone?.(data) }
          else if (currentEvent === 'error') { receivedTerminalEvent = true; callbacks.onError?.(data.message || '未知错误') }
        } catch { /* 跳过格式错误的 SSE 数据，不中断整个流 */ }
      }

      // 循环读取流数据
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, '\n')
        // SSE 帧以 \n\n 分隔
        let frameEnd = buffer.indexOf('\n\n')
        while (frameEnd >= 0) {
          const frame = buffer.slice(0, frameEnd)
          buffer = buffer.slice(frameEnd + 2)
          processFrame(frame)
          frameEnd = buffer.indexOf('\n\n')
        }
      }
      // 处理缓冲区中剩余的最后一个帧
      if (buffer.trim()) processFrame(buffer)
      if (!receivedTerminalEvent) callbacks.onError?.('回答已中断，请重试')
    })
    .catch((err) => {
      if (err.name !== 'AbortError') callbacks.onError?.(err.message || '网络错误')
    })
  return controller
}

// ===== 问答历史管理 =====

/** 获取问答历史列表（按对话分组，置顶优先） */
export async function listHistory(): Promise<HistoryItem[]> {
  const { data } = await api.get('/rag/history')
  return groupHistoryByConversation(data || [])
}
/** 获取单条历史详情（含多轮消息） */
export async function getHistory(id: string): Promise<HistoryItem> { const { data } = await api.get(`/rag/history/${id}`); return data }
/** 删除单条历史 */
export async function deleteHistory(id: string): Promise<void> { await api.delete(`/rag/history/${id}`) }
/** 重命名历史记录标题 */
export async function renameHistory(id: string, title: string): Promise<HistoryItem> { const { data } = await api.patch(`/rag/history/${id}/title`, { title }); return data }
/** 切换置顶状态 */
export async function togglePinHistory(id: string): Promise<HistoryItem> { const { data } = await api.patch(`/rag/history/${id}/pin`); return data }
/** 清空所有历史 */
export async function clearHistory(): Promise<void> { await api.delete('/rag/history') }

// ===== 资料摘要 =====

/** 为资料生成 AI 摘要 */
export async function summarizeMaterial(materialId: string): Promise<SummaryResult> { const { data } = await api.post('/rag/summarize', { materialId }); return data }
/** 获取资料的最新摘要 */
export async function getMaterialSummary(materialId: string): Promise<SummaryResult> { const { data } = await api.get(`/rag/summaries/${materialId}`); return data }
/** 获取资料的所有历史摘要版本 */
export async function listMaterialSummaries(materialId: string): Promise<SummaryResult[]> { const { data } = await api.get(`/rag/summaries/${materialId}/history`); return data }

// ===== RAG 评估套件 =====

/** 即时运行评估（不保存套件） */
export async function runEvaluationSuite(payload: RagEvaluationSuitePayload): Promise<RagEvaluationSuiteResult> { const { data } = await api.post('/rag/evaluation-suite', payload); return data }
function normalizeEvaluationSuiteSummary(item: RagEvaluationSuiteSummary): RagEvaluationSuiteSummary { return { ...item, id: String(item.id) } }
function normalizeEvaluationSuiteRun(item: RagEvaluationSuiteRun): RagEvaluationSuiteRun { return { ...item, id: String(item.id), suiteId: String(item.suiteId) } }
function normalizeEvaluationSuiteDetail(item: RagEvaluationSuiteDetail): RagEvaluationSuiteDetail { return { ...item, id: String(item.id), latestRun: item.latestRun ? normalizeEvaluationSuiteRun(item.latestRun) : null } }
/** 获取已保存的评估套件列表 */
export async function listEvaluationSuites(): Promise<RagEvaluationSuiteSummary[]> { const { data } = await api.get('/rag/evaluation-suites'); return (data || []).map(normalizeEvaluationSuiteSummary) }
/** 获取单个评估套件详情（含用例） */
export async function getEvaluationSuite(id: string): Promise<RagEvaluationSuiteDetail> { const { data } = await api.get(`/rag/evaluation-suites/${id}`); return normalizeEvaluationSuiteDetail(data) }
/** 新建评估套件 */
export async function saveEvaluationSuite(payload: RagEvaluationSuiteSavePayload): Promise<RagEvaluationSuiteDetail> { const { data } = await api.post('/rag/evaluation-suites', payload); return normalizeEvaluationSuiteDetail(data) }
/** 更新评估套件 */
export async function updateEvaluationSuite(id: string, payload: RagEvaluationSuiteSavePayload): Promise<RagEvaluationSuiteDetail> { const { data } = await api.put(`/rag/evaluation-suites/${id}`, payload); return normalizeEvaluationSuiteDetail(data) }
/** 删除评估套件 */
export async function deleteEvaluationSuite(id: string): Promise<void> { await api.delete(`/rag/evaluation-suites/${id}`) }
/** 运行已保存的评估套件 */
export async function runSavedEvaluationSuite(id: string): Promise<RagEvaluationSuiteRun> { const { data } = await api.post(`/rag/evaluation-suites/${id}/runs`); return normalizeEvaluationSuiteRun(data) }
/** 获取评估套件的运行历史 */
export async function listEvaluationSuiteRuns(id: string): Promise<RagEvaluationSuiteRun[]> { const { data } = await api.get(`/rag/evaluation-suites/${id}/runs`); return (data || []).map(normalizeEvaluationSuiteRun) }
/** 更新评估套件的定时调度设置 */
export async function updateEvaluationSuiteSchedule(id: string, payload: { scheduled: boolean; intervalHours: number }): Promise<RagEvaluationSuiteDetail> { const { data } = await api.patch(`/rag/evaluation-suites/${id}/schedule`, payload); return normalizeEvaluationSuiteDetail(data) }

/** 根据当前分块内容生成推荐问题（阅读器中使用） */
export async function suggestQuestions(materialId: string, chunkId?: string): Promise<string[]> {
  const params = new URLSearchParams({ materialId })
  if (chunkId) params.set('chunkId', chunkId)
  const { data } = await api.get(`/rag/suggest-questions?${params}`)
  return data || []
}

// ===== 历史分组逻辑 =====

/**
 * 将历史记录按 conversationId 分组。
 * 同一组对话只保留最新的一条（用于列表展示）。
 * 置顶的对话排在最前面。
 */
function groupHistoryByConversation(items: HistoryItem[]): HistoryItem[] {
  const grouped = new Map<string, HistoryItem>()
  const localConversationMap = readLocalConversationMap()
  for (const item of items) {
    const itemId = String(item.id)
    const key = String(item.conversationId || localConversationMap[itemId] || itemId)
    const current = grouped.get(key)
    if (!current || new Date(item.createdAt).getTime() > new Date(current.createdAt).getTime()) {
      grouped.set(key, { ...item, conversationId: key })
    }
  }
  return Array.from(grouped.values()).sort((left, right) => {
    if (left.pinned !== right.pinned) return left.pinned ? -1 : 1  // 置顶优先
    return new Date(right.createdAt).getTime() - new Date(left.createdAt).getTime()  // 时间倒序
  })
}
function readLocalConversationMap() {
  if (typeof window === 'undefined') return {}
  try { return JSON.parse(localStorage.getItem(CHAT_HISTORY_CONVERSATION_KEY) || '{}') }
  catch { localStorage.removeItem(CHAT_HISTORY_CONVERSATION_KEY); return {} }
}

// ===== React Hooks =====
export function useChat() { return useMutation({ mutationFn: chat, onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['history'] }); queryClient.invalidateQueries({ queryKey: ['rag-usage'] }); queryClient.invalidateQueries({ queryKey: ['admin', 'usage-records'] }) } }) }
export function useRagUsage() { return useQuery({ queryKey: ['rag-usage'], queryFn: getRagUsage }) }
export function useHistory() { return useQuery({ queryKey: ['history'], queryFn: listHistory }) }
export function useHistoryDetail(id: string | null) { return useQuery({ queryKey: ['history', id], queryFn: () => getHistory(id!), enabled: !!id }) }
export function useDeleteHistory() { return useMutation({ mutationFn: deleteHistory, onSuccess: () => queryClient.invalidateQueries({ queryKey: ['history'] }) }) }
export function useRenameHistory() { return useMutation({ mutationFn: ({ id, title }: { id: string; title: string }) => renameHistory(id, title), onSuccess: () => queryClient.invalidateQueries({ queryKey: ['history'] }) }) }
export function useTogglePinHistory() { return useMutation({ mutationFn: togglePinHistory, onSuccess: () => queryClient.invalidateQueries({ queryKey: ['history'] }) }) }
export function useClearHistory() { return useMutation({ mutationFn: clearHistory, onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['history'] }); queryClient.invalidateQueries({ queryKey: ['favorites'] }) } }) }
export function useSummarizeMaterial() { return useMutation({ mutationFn: summarizeMaterial, onSuccess: (_d, materialId) => { queryClient.invalidateQueries({ queryKey: ['summaries', materialId] }) } }) }
export function useMaterialSummary(materialId: string | null) { return useQuery({ queryKey: ['summaries', materialId], queryFn: () => getMaterialSummary(materialId!), enabled: !!materialId }) }
export function useMaterialSummaryHistory(materialId: string | null) { return useQuery({ queryKey: ['summaries', materialId, 'history'], queryFn: () => listMaterialSummaries(materialId!), enabled: !!materialId }) }
export function useRunEvaluationSuite() { return useMutation({ mutationFn: runEvaluationSuite }) }
export function useEvaluationSuites() { return useQuery({ queryKey: ['rag-evaluation-suites'], queryFn: listEvaluationSuites }) }
export function useEvaluationSuiteDetail(id: string | null) { return useQuery({ queryKey: ['rag-evaluation-suites', id], queryFn: () => getEvaluationSuite(id!), enabled: !!id }) }
export function useEvaluationSuiteRuns(id: string | null) { return useQuery({ queryKey: ['rag-evaluation-suites', id, 'runs'], queryFn: () => listEvaluationSuiteRuns(id!), enabled: !!id }) }
export function useSaveEvaluationSuite() { return useMutation({ mutationFn: saveEvaluationSuite, onSuccess: () => queryClient.invalidateQueries({ queryKey: ['rag-evaluation-suites'] }) }) }
export function useUpdateEvaluationSuite() { return useMutation({ mutationFn: ({ id, payload }: { id: string; payload: RagEvaluationSuiteSavePayload }) => updateEvaluationSuite(id, payload), onSuccess: (_d, v) => { queryClient.invalidateQueries({ queryKey: ['rag-evaluation-suites'] }); queryClient.invalidateQueries({ queryKey: ['rag-evaluation-suites', v.id] }) } }) }
export function useDeleteEvaluationSuite() { return useMutation({ mutationFn: deleteEvaluationSuite, onSuccess: () => queryClient.invalidateQueries({ queryKey: ['rag-evaluation-suites'] }) }) }
export function useRunSavedEvaluationSuite() { return useMutation({ mutationFn: runSavedEvaluationSuite, onSuccess: (_d, id) => { queryClient.invalidateQueries({ queryKey: ['rag-evaluation-suites'] }); queryClient.invalidateQueries({ queryKey: ['rag-evaluation-suites', id] }); queryClient.invalidateQueries({ queryKey: ['rag-evaluation-suites', id, 'runs'] }) } }) }
export function useUpdateEvaluationSuiteSchedule() { return useMutation({ mutationFn: ({ id, payload }: { id: string; payload: { scheduled: boolean; intervalHours: number } }) => updateEvaluationSuiteSchedule(id, payload), onSuccess: (_d, v) => { queryClient.invalidateQueries({ queryKey: ['rag-evaluation-suites'] }); queryClient.invalidateQueries({ queryKey: ['rag-evaluation-suites', v.id] }) } }) }
